#define MINIZ_HEADER_FILE_ONLY
#include "miniz.c"
